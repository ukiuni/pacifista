package org.ukiuni.pacifista;

public class Console {
	public void log(Object message) {
		System.out.println(message);
	}
}
